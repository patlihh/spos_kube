# kubecluster-ansible (not workable yet)



A ansible script to installs kube cluster on CentOS 7

## Features
* 
* 
*  


## Requirements

* ansible 2.4


## Example

modify inventories, then

```
ansible-playbook -i inventories/dev/hosts deploy-kube-cluster.yml
```

check .txt for detailed intro
